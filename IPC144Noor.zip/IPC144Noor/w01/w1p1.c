#include <stdio.h>
int main(void) {

    printf("Workshop 1 Part-1\n"
    
           "=================\n\n");
    
    
    printf("I'm displaying this using the 'printf' stdio\n"
           "(standard input output) library function!\n\n");
    
    printf("Dear teacher,\n\n");
    
    printf("  I promise I will work hard from this day onward.\n"
           "  I acknowledge that practice is extremely important,\n"
           "  so I will do all workshops, quizzes, and assignments.\n\n");
    
    printf("Sincerely,\n\n");
    
    printf("Navnoor Singh\n"
           "Student ID# 160821211\n");

   return 0;
}

